<?php

	session_start();
	
	session_destroy();
	?>
		<script>
			window.location="../index.html";
		</script>
	<?php

?>