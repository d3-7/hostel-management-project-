-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 02, 2022 at 11:39 AM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 8.1.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bcrec`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_detail`
--

CREATE TABLE `admin_detail` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(50) NOT NULL,
  `mobile` varchar(12) NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin_detail`
--

INSERT INTO `admin_detail` (`id`, `name`, `email`, `password`, `mobile`, `date`) VALUES
(1, 'hemang', 'admin@gmail.com', '1234', '9122430437', '2021-03-03 14:08:49');

-- --------------------------------------------------------

--
-- Table structure for table `bookings`
--

CREATE TABLE `bookings` (
  `booking_id` int(11) NOT NULL,
  `block` varchar(10) NOT NULL,
  `room_type` varchar(30) NOT NULL,
  `booking_from` varchar(20) NOT NULL,
  `room_charge` varchar(10) NOT NULL,
  `room_no` varchar(10) NOT NULL,
  `student_name` varchar(100) NOT NULL,
  `mobile` varchar(12) NOT NULL,
  `email` varchar(50) NOT NULL,
  `status` varchar(30) NOT NULL DEFAULT 'pending',
  `booking_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `food_type` varchar(255) NOT NULL,
  `mess_charge` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `bookings`
--

INSERT INTO `bookings` (`booking_id`, `block`, `room_type`, `booking_from`, `room_charge`, `room_no`, `student_name`, `mobile`, `email`, `status`, `booking_date`, `food_type`, `mess_charge`) VALUES
(9, 'a', 'Single Bed Room', '2022-03-02', '5000', '101', 'kachhiya patel dhaval dilipbhai', '7359330223', 'KACHHIYAPATELDHAVAL@GMAIL.COM', 'Approved', '2022-03-01 11:19:21', 'Veg Food', 3000),
(11, 'b', 'Triple Bed Room', '2022-03-10', '3000', '202', 'test user1', '45963215', 'test@gmail.com', 'Approved', '2022-03-01 11:30:26', 'Veg Food', 3000),
(12, 'd', 'Single Bed Room', '2022-08-16', '5000', '101', 'test user2', '123456963', 'test2@gmail.com', 'Approved', '2022-03-01 11:34:00', 'Non-Veg Food', 5000),
(13, 'b', 'Triple Bed Room', '2022-04-14', '3000', '202', 'test3', '6756184515', 'test3@gmail.com', 'Reject', '2022-03-01 11:36:35', 'Veg Food', 3000);

-- --------------------------------------------------------

--
-- Table structure for table `register_form`
--

CREATE TABLE `register_form` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `mobile` varchar(12) NOT NULL,
  `email` varchar(30) NOT NULL,
  `password` varchar(30) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `address` varchar(500) NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `register_form`
--

INSERT INTO `register_form` (`id`, `name`, `mobile`, `email`, `password`, `gender`, `address`, `date`) VALUES
(9, 'kachhiya patel dhaval dilipbhai', '7359330223', 'KACHHIYAPATELDHAVAL@GMAIL.COM', '2580', 'Boys', 'dholka , ahmedabad', '2022-03-01 08:30:14'),
(10, 'test user1', '45963215', 'test@gmail.com', 'test', 'Boys', 'mumbai ', '2022-03-01 11:23:00'),
(11, 'test user2', '123456963', 'test2@gmail.com', 'test2', 'Girls', 'delhi', '2022-03-01 11:32:58'),
(12, 'test3', '6756184515', 'test3@gmail.com', 'test3', 'Boys', 'uttar pradesh', '2022-03-01 11:35:32');

-- --------------------------------------------------------

--
-- Table structure for table `rooms`
--

CREATE TABLE `rooms` (
  `id` int(11) NOT NULL,
  `type` varchar(30) NOT NULL,
  `block` varchar(20) NOT NULL,
  `room_no` varchar(10) NOT NULL,
  `charge` varchar(10) NOT NULL,
  `room_for` varchar(10) NOT NULL,
  `total_bed` varchar(10) NOT NULL,
  `avilable_bed` varchar(10) NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `rooms`
--

INSERT INTO `rooms` (`id`, `type`, `block`, `room_no`, `charge`, `room_for`, `total_bed`, `avilable_bed`, `date`) VALUES
(10, 'Single Bed Room', 'a', '101', '5000', 'Boys', '1', '0', '2022-03-01 08:31:49'),
(11, 'Triple Bed Room', 'b', '202', '3000', 'Boys', '3', '2', '2022-03-01 08:32:07'),
(12, 'Double Bed Room', 'b', '102', '3000', 'Boys', '2', '2', '2022-03-01 11:25:08'),
(13, 'Triple Bed Room', 'c', '303', '1500', 'Boys', '3', '3', '2022-03-01 11:25:28'),
(14, 'Single Bed Room', 'd', '101', '5000', 'Girls', '1', '0', '2022-03-01 11:31:42');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_detail`
--
ALTER TABLE `admin_detail`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `bookings`
--
ALTER TABLE `bookings`
  ADD PRIMARY KEY (`booking_id`);

--
-- Indexes for table `register_form`
--
ALTER TABLE `register_form`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `rooms`
--
ALTER TABLE `rooms`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin_detail`
--
ALTER TABLE `admin_detail`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `bookings`
--
ALTER TABLE `bookings`
  MODIFY `booking_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `register_form`
--
ALTER TABLE `register_form`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `rooms`
--
ALTER TABLE `rooms`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
